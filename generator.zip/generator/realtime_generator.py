import pandas as pd
import time
import random

class RealTimeDataGenerator:
    def __init__(self, gps_path='test_gps.csv', lidar_path='test_lidar.csv', hack_frequency=10):
        self.gps_data = pd.read_csv(gps_path)
        self.lidar_data = pd.read_csv(lidar_path)
        self.hack_frequency = hack_frequency

        # Ensure data lengths are the same
        min_len = min(len(self.gps_data), len(self.lidar_data))
        self.gps_data = self.gps_data.iloc[:min_len].reset_index(drop=True)
        self.lidar_data = self.lidar_data.iloc[:min_len].reset_index(drop=True)

    def stream_data(self, callback, interval=1.0):
        for i in range(len(self.gps_data)):
            gps_row = self.gps_data.iloc[i:i+1].copy()
            lidar_row = self.lidar_data.iloc[i:i+1].copy()

            # Determine if this frame is "hacked"
            is_hacked = (random.randint(1, self.hack_frequency) == 1)

            # Call the user-defined callback function
            callback(gps_row, lidar_row, is_hacked)

            # Simulate real-time delay
            time.sleep(interval)
