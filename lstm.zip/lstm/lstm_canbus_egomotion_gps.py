import pandas as pd
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Bidirectional, LayerNormalization
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from imblearn.over_sampling import SMOTE  # Handle class imbalance
import joblib

# Load datasets
can_bus_df = pd.read_csv(r"lstm\dataset\training data\synthetic_can_bus.csv")
gps_imu_df = pd.read_csv(r"lstm\dataset\training data\synthetic_gps_imu.csv")
egomotion_df = pd.read_csv(r"lstm\dataset\training data\synthetic_egomotion_with_bias.csv")

# Encode categorical variables if present
categorical_cols = ['Gear_Position']
encoder = LabelEncoder()

for col in categorical_cols:
    if col in can_bus_df.columns and can_bus_df[col].dtype == 'O':
        can_bus_df[col] = encoder.fit_transform(can_bus_df[col])

# Feature selection
can_bus_features = ['Throttle_Position', 'Brake_Pressure', 'Steering_Angle', 'Vehicle_Speed', 'Gear_Position']
gps_imu_features = ['Latitude', 'Longitude', 'Speed', 'Heading', 'Acceleration_X', 'Acceleration_Y']
egomotion_features = ['Rotation_X', 'Rotation_Y', 'Rotation_Z', 'Position_X', 'Velocity_X', 'Velocity_Y']

# Target variable
label_col = 'Threat_Type'
if label_col in can_bus_df.columns:
    y = can_bus_df[label_col]
    y = encoder.fit_transform(y)  # Ensure encoding
else:
    raise KeyError(f"'{label_col}' not found in can_bus_df")

# Merge datasets
combined_df = pd.concat([can_bus_df[can_bus_features], gps_imu_df[gps_imu_features], egomotion_df[egomotion_features]], axis=1)

# Handle missing values
combined_df.fillna(combined_df.median(), inplace=True)

# Data preprocessing
scaler = StandardScaler()
X = scaler.fit_transform(combined_df)

# Handle class imbalance with SMOTE
smote = SMOTE(random_state=42)
X, y = smote.fit_resample(X, y)

# Reshape for LSTM
X = X.reshape(X.shape[0], X.shape[1], 1)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Data augmentation (Gaussian noise)
noise = np.random.normal(0, 0.05, X_train.shape)  # Reduced noise for better augmentation
X_train_augmented = X_train + noise

# Determine model output settings
num_classes = len(np.unique(y))
activation = "sigmoid" if num_classes == 2 else "softmax"
loss_fn = "binary_crossentropy" if num_classes == 2 else "sparse_categorical_crossentropy"

# Improved LSTM Model
lstm_model = Sequential([
    Bidirectional(LSTM(128, return_sequences=True, input_shape=(X_train.shape[1], 1))),
    LayerNormalization(),
    Dropout(0.3),

    Bidirectional(LSTM(64, return_sequences=True, kernel_regularizer=tf.keras.regularizers.l2(0.001))),
    LayerNormalization(),
    Dropout(0.3),

    Bidirectional(LSTM(32)),
    LayerNormalization(),
    Dense(32, activation='relu'),
    Dropout(0.2),

    Dense(num_classes, activation=activation)
])

# Optimized Learning Rate
opt = Adam(learning_rate=0.001)

# Compile model
lstm_model.compile(optimizer=opt, loss=loss_fn, metrics=['accuracy'])

# Learning rate reduction on plateau
reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6)

# Early stopping
early_stop = EarlyStopping(monitor='val_loss', patience=7, restore_best_weights=True)

# Train model with increased batch size
lstm_model.fit(X_train_augmented, y_train, epochs=20, batch_size=64, validation_data=(X_test, y_test), callbacks=[early_stop, reduce_lr])

# Save model and preprocessing tools
lstm_model.save("lstm_model_optimized.h5")  # Save in .h5 format
joblib.dump(scaler, "scaler.pkl")
joblib.dump(encoder, "label_encoder.pkl")
