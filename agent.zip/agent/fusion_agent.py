from agent.gps_model import GPSModel
from agent.lidar_model import LidarModel
from agent.traffic_classifier import TrafficClassifier

class IntrusionDetectionAgent:
    def __init__(self):
        self.gps_model = GPSModel("models/lstm_model_optimized.h5", "models/scaler.pkl")
        self.lidar_model = LidarModel("models/cnn_model_lidar_radar_enhanced.h5", "models/scaler_lidar_radar_enhanced.pkl")
        self.classifier = TrafficClassifier("models/lstm_traffic_classifier.h5")

    def analyze(self, gps_df, lidar_df):
        gps_feature = self.gps_model.extract_feature(gps_df)
        lidar_feature = self.lidar_model.extract_feature(lidar_df)
        result = self.classifier.predict_anomaly(gps_feature, lidar_feature)
        return {
            "GPS Feature": gps_feature.tolist(),
            "Lidar Feature": lidar_feature.tolist(),
            "Hacking Detected": bool(result)
        }
