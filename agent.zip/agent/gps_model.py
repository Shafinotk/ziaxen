# import numpy as np
# import pandas as pd
# from tensorflow.keras.models import load_model
# import joblib

# class GPSModel:
#     def __init__(self, model_path, scaler_path):
#         self.model = load_model(model_path)
#         self.scaler = joblib.load(scaler_path)

#     def extract_feature(self, gps_data: pd.DataFrame):
#         gps_scaled = self.scaler.transform(gps_data)
#         gps_input = gps_scaled.reshape((gps_scaled.shape[0], 1, gps_scaled.shape[1]))
#         feature = self.model.predict(gps_input)
#         return feature
#     print(self.scaler.feature_names_in_)  # Inspect the feature names the scaler expects

import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
import joblib

class GPSModel:
    def __init__(self, model_path, scaler_path):
        self.model = load_model(model_path)
        self.scaler = joblib.load(scaler_path)
        print(self.scaler.feature_names_in_)  # Moved here inside __init__

    def extract_feature(self, gps_data):
        expected_columns = [
            'Throttle_Position', 'Brake_Pressure', 'Steering_Angle', 'Vehicle_Speed',
            'Gear_Position', 'Latitude', 'Longitude', 'Speed', 'Heading', 'Acceleration_X',
            'Acceleration_Y', 'Rotation_X', 'Rotation_Y', 'Rotation_Z', 'Position_X',
            'Velocity_X', 'Velocity_Y'
        ]

        missing_columns = [col for col in expected_columns if col not in gps_data.columns]
        if missing_columns:
            raise ValueError(f"Missing columns in gps_data: {missing_columns}")

        # Filter and convert to numeric
        gps_data_filtered = gps_data[expected_columns].copy()
        gps_data_filtered = gps_data_filtered.apply(pd.to_numeric, errors='coerce')

        # Handle missing values
        if gps_data_filtered.isnull().values.any():
            print("[WARNING] Null values found after conversion. Filling with column mean.")
            gps_data_filtered = gps_data_filtered.fillna(gps_data_filtered.mean())

        gps_scaled = self.scaler.transform(gps_data_filtered)

        return gps_scaled


if __name__ == "__main__":
    model_path = r"C:\Users\shafi\Downloads\Telegram Desktop\techzia\techzia\ziaxen\models\lstm_model_optimized.h5"
    scaler_path = r"C:\Users\shafi\Downloads\Telegram Desktop\techzia\techzia\ziaxen\models\scaler.pkl"
    
    gps_model = GPSModel(model_path, scaler_path)
