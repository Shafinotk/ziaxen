import numpy as np
import pandas as pd
from tensorflow.keras.models import load_model
import joblib
from sklearn.experimental import enable_iterative_imputer
from sklearn.impute import IterativeImputer

class LidarModel:
    def __init__(self, model_path, scaler_path):
        self.model = load_model(model_path)
        self.scaler = joblib.load(scaler_path)

    def extract_feature(self, lidar_data: pd.DataFrame):
        # Print the columns of lidar_data
        print("Columns of lidar_data:")
        print(lidar_data.columns)

        # Feature Engineering (adding missing features)
        lidar_data['Velocity_Magnitude'] = np.sqrt(lidar_data['Speed']**2 + lidar_data['Azimuth']**2)
        lidar_data['Velocity_Range_Ratio'] = lidar_data['Speed'] / (lidar_data['Range'] + 1e-5)
        lidar_data['Log_Intensity'] = np.log1p(lidar_data['Intensity'])
        lidar_data['Power_Noise_Ratio'] = lidar_data['Power'] / (lidar_data['Noise'] + 1e-5)

        # Define the expected column order (this should match what the scaler was fitted on)
        expected_columns = ['X', 'Y', 'Z', 'Intensity', 'Azimuth', 'Elevation', 'Range',
                            'Speed', 'RCS', 'Power', 'Noise', 'Velocity_Magnitude',
                            'Velocity_Range_Ratio', 'Log_Intensity', 'Power_Noise_Ratio']
        
        # Reorder columns to match the scaler's expected input
        lidar_data_filtered = lidar_data[expected_columns].copy()

        # Check for missing columns and add them with default values
        missing_cols = [col for col in expected_columns if col not in lidar_data_filtered.columns]
        for col in missing_cols:
            lidar_data_filtered[col] = 0  # Add missing columns, default to 0 or another strategy

        # Ensure correct column order (to match scaler's expected order)
        lidar_data_filtered = lidar_data_filtered[expected_columns]

        # Impute missing values (use the same strategy as in training)
        imputer = IterativeImputer(max_iter=10, random_state=42)
        lidar_data_filtered[:] = imputer.fit_transform(lidar_data_filtered)

        # Scale the data using the fitted scaler
        lidar_scaled = self.scaler.transform(lidar_data_filtered)

        # Reshape for model input (as required by CNN)
        lidar_input = lidar_scaled.reshape((lidar_scaled.shape[0], lidar_scaled.shape[1], 1))

        # Predict features using the model
        feature = self.model.predict(lidar_input)

        return feature
