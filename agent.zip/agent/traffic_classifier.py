import numpy as np
from tensorflow.keras.models import load_model

class TrafficClassifier:
    def __init__(self, model_path):
        self.model = load_model(model_path)

    def predict_anomaly(self, feature_a, feature_b):
        # Combine features along axis 1 (horizontally)
        combined = np.concatenate([feature_a, feature_b], axis=1)

        # Ensure we only take the first 4 features (if there are more than 4)
        combined = combined[:, :4]

        # Reshape combined to (batch_size, 1, 4) for CNN input
        combined = np.reshape(combined, (combined.shape[0], 1, 4))

        # Make the prediction
        prediction = self.model.predict(combined)

        # Return the result (0 = Safe, 1 = Hack)
        return int(prediction[0][0] > 0.5)
