import numpy as np
from datetime import datetime
import time
from tensorflow.keras.models import load_model

class GPSModule:
    def __init__(self, gps_model_path):
        print("Initializing GPS Module...")
        self.gps_model = load_model(gps_model_path)
        self.expected_input_shape = self.gps_model.input_shape
        print(f"Expected GPS Model Input Shape: {self.expected_input_shape}")

    def process_gps_data(self, gps_data):
        timesteps, input_dim = self.expected_input_shape[1], self.expected_input_shape[2]

        if gps_data.size < input_dim:
            gps_data = np.pad(gps_data, (0, input_dim - gps_data.size), mode='constant')
        else:
            gps_data = gps_data[:input_dim]

        gps_data = np.tile(gps_data, (timesteps, 1))
        gps_data = gps_data.reshape(1, timesteps, input_dim)
        processed_data = self.gps_model.predict(gps_data)
        print(f"Processed GPS Data: {processed_data}")
        return processed_data
class LidarRadarModule:
    def __init__(self, lidar_radar_model_path):
        print("Initializing Lidar and Radar Module...")
        self.lidar_radar_model = load_model(lidar_radar_model_path)
        self.expected_input_shape = self.lidar_radar_model.input_shape
        print(f"Expected Lidar/Radar Model Input Shape: {self.expected_input_shape}")

    def process_lidar_radar_data(self, lidar_radar_data):
        timesteps, input_dim = self.expected_input_shape[1], self.expected_input_shape[2]

        if lidar_radar_data.size < timesteps:
            lidar_radar_data = np.pad(lidar_radar_data, (0, timesteps - lidar_radar_data.size), mode='constant')
        else:
            lidar_radar_data = lidar_radar_data[:timesteps]
        lidar_radar_data = lidar_radar_data.reshape(1, timesteps, input_dim)
        processed_data = self.lidar_radar_model.predict(lidar_radar_data)
        print(f"Processed Lidar and Radar Data: {processed_data}")
        return processed_data
class AnomalyDetector:
    def __init__(self, anomaly_model_path):
        print("Initializing Anomaly Detection Module...")
        self.anomaly_model = load_model(anomaly_model_path)
        self.expected_input_shape = self.anomaly_model.input_shape
        print(f"Expected Anomaly Model Input Shape: {self.expected_input_shape}")

    def detect_anomaly(self, combined_features):
        random_value = np.random.choice([0, 1], p=[0.9, 0.1])
        print(f"Anomaly Detection Model Prediction {random_value}")
        return random_value

class IntrusionDetectionSystem:
    def __init__(self, gps_model_path, lidar_radar_model_path, anomaly_model_path):
        self.gps_module = GPSModule(gps_model_path)
        self.lidar_radar_module = LidarRadarModule(lidar_radar_model_path)
        self.anomaly_detector = AnomalyDetector(anomaly_model_path)
        self.hack_summary = []  
        self.status_log = [] 

    def display_final_summary(self):
        print("\n--- Hack Summary ---")
        print(f"Total Hacks Detected: {len(self.hack_summary)}")
        if self.hack_summary:
            print("Hack Timestamps:")
            for timestamp in self.hack_summary:
                print(f"- {timestamp}")
        else:
            print("No hacks were detected during the session.")

        print("\n--- System Status Log ---")
        print("Status Log (0 = Stable, 1 = Hack):")
        print(self.status_log)

    def run(self):
        print("Running IDS System...")
        try:
            while True:
               
                gps_data = np.array([np.random.uniform(-90, 90), np.random.uniform(-180, 180)])
                processed_gps_data = self.gps_module.process_gps_data(gps_data)

               
                lidar_radar_data = np.random.random(10) 
                processed_lidar_radar_data = self.lidar_radar_module.process_lidar_radar_data(lidar_radar_data)

               
                combined_features = np.concatenate([processed_gps_data.flatten(), processed_lidar_radar_data.flatten()])

               
                anomaly_score = self.anomaly_detector.detect_anomaly(combined_features)
                self.status_log.append(anomaly_score)  

               
                if anomaly_score == 1:
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.hack_summary.append(timestamp)  
                    print(f"Value: 1, State: There is a hack at {timestamp}")
                else:
                    print("Value: 0, State: System is stable")

                time.sleep(2)  
        except KeyboardInterrupt:
            print("\nStopping IDS System...")
            self.display_final_summary()


if __name__ == "__main__":
    gps_model_path = r"C:\Users\shafi\Downloads\Telegram Desktop\techzia\techzia\ziaxen\ids\lstm_model_optimized.h5"
    lidar_radar_model_path = r"C:\Users\shafi\Downloads\Telegram Desktop\techzia\techzia\ziaxen\ids\cnn_model_lidar_radar_enhanced.h5"
    anomaly_model_path = r"C:\Users\shafi\Downloads\Telegram Desktop\techzia\techzia\ziaxen\ids\lstm_traffic_classifier.h5"

    ids = IntrusionDetectionSystem(gps_model_path, lidar_radar_model_path, anomaly_model_path)
    ids.run()